var searchData=
[
  ['screencenter',['screenCenter',['../classBuildSystem_1_1ObjectPlacer.html#a51dd0b4ec0b33b5b823b6d65a7f3eeeba6ddea3b4b9796b3dc8d0f1e2a6acf15f',1,'BuildSystem::ObjectPlacer']]],
  ['snap',['snap',['../classBuildSystem_1_1ObjectPlacer.html#a57ff13c9f948df32b09fa6e86af0a8f1af5e975aa551d1ae4e91e8ce93b9696b0',1,'BuildSystem::ObjectPlacer']]]
];

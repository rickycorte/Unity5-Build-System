var searchData=
[
  ['name',['Name',['../classBuildSystem_1_1BuildItem.html#a74bbc407dc4f73036163fc2840516904',1,'BuildSystem::BuildItem']]]
];

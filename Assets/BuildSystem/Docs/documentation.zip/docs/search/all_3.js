var searchData=
[
  ['deletepivot',['DeletePivot',['../classBuildSystem_1_1PivotHelper.html#a2c45c3aa3de960bb672a2d9a4c54251a',1,'BuildSystem::PivotHelper']]]
];

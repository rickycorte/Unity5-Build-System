var searchData=
[
  ['deletepivot',['DeletePivot',['../class_build_system_1_1_pivot_helper.html#ac938eae6782852d14e6b89f9ddd973b3',1,'BuildSystem::PivotHelper']]]
];

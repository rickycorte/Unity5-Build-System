var searchData=
[
  ['buildsystem',['BuildSystem',['../namespace_build_system.html',1,'']]]
];
